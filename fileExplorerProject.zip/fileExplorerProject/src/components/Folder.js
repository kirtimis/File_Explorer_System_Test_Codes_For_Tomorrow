import { useState } from "react"

export default function Folder({explorer})
{
    //console.log(explorer)
    const [expand,setExpand]=useState(false)
    const  [showInput,setShowInput]=useState({
        visible:false,
        isFolder:null
    })

    function handleNewFolder(e,isFolder)
    {
        e.stopPropagation()

        setShowInput(
            {
                visible:true,
                isFolder

            }
        )
    }
    if(explorer.isFolder)
    {
        return(<div style={{marginTop:5}}>
            <div  >
                <span className="folder" onClick={()=>setExpand(!expand)}>
                    📁{explorer.name}
                    <div>
                    <button onClick={(e)=>handleNewFolder(e,true)}>Folder +</button>
                    <button onClick={(e)=>handleNewFolder(e,false)}>File +</button>
                </div>
                </span>
               
            </div>
            <div style={{backgroundColor:"white",paddingLeft:"25px",display: expand?"block":"none"}}>
                {
                    showInput.visible && (
                        <div>
                            <span>{showInput.isFolder?"📁":"🗄"}</span>
                            <input className="inputContainer__input"
                            type="text"
                            autoFocus
                            onBlur={()=>setShowInput({...showInput,visible:false})}
                            />
                        </div>
                    )
                }
                {explorer.items.map((exp)=>{
                    return(
                       <Folder explorer={exp} key={exp.id}/>
                    )
                })}
            </div>
        </div>)
    }

    else{
        return(
            <span className="file">🗄{explorer.name}</span>
        )
       
    }
    
}